package common

// Location represents a locality-based group of LIFX devices
type Location interface {
	// Location is a group
	Group
}
