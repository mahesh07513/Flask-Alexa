// Package common contains common elements for the golifx client and protocols
package common
