// Package shared contains shared elements of the LIFX LAN protocol version 2.
//
// This package is not designed to be accessed by end users, all interaction
// should occur via the Client in the golifx package.
package shared
