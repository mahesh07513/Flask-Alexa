package shared

type Message uint16
