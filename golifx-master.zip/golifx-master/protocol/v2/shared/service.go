package shared

type Service uint8

const (
	ServiceUDP Service = iota
	serviceReserved0
	serviceReserved1
	serviceReserved2
)
